package controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.service.UnitConverter;
import model.service.UnitConverter.Unit;
import view.util.EditCell;

import java.util.*;

/**
 * Controller for initMemory.fxml.
 *
 * Responsibilities:
 *   - Let the user pick the INPUT unit (B / KB / MB / GB) once per session.
 *   - Accept total memory size and hole definitions in that unit.
 *   - Validate that every byte count is a positive power of two.
 *   - Return raw BYTES to MainController (no unit information leaks out).
 *
 * The display unit (tables / diagram) is completely separate and lives
 * in UnitConverter.displayUnit, controlled by the main window ComboBox.
 */
public class InitMemoryController {

    // ── FXML ──────────────────────────────────────────────────────────────
    @FXML private Label                         lblTotalSize;
    @FXML private TextField                     tfTotalSize;
    @FXML private ComboBox<Unit>                cbInputUnit;   // NEW — input unit picker
    @FXML private TableView<String[]>           holesTable;
    @FXML private TableColumn<String[], String> holeStart, holeSize;

    private final ObservableList<String[]> rows = FXCollections.observableArrayList();

    // ── Result ────────────────────────────────────────────────────────────
    private boolean   confirmed     = false;
    private long      totalSizeBytes;             // raw bytes, always
    private final List<long[]> holes = new ArrayList<>();  // [startBytes, sizeBytes]

    // ── Session persistence ───────────────────────────────────────────────
    private static long           lastTotalBytes = 1024L;
    private static Unit           lastInputUnit  = Unit.B;
    private static final List<String[]> lastRows = new ArrayList<>();
    private static boolean        hasInit        = false;

    // ── Injected ──────────────────────────────────────────────────────────
    private UnitConverter units;

    /** Called by MainController immediately after FXMLLoader.load(). */
    public void setUnitConverter(UnitConverter units) {
        this.units = units;
        // Re-apply once injection arrives (initialize() may have run first)
        if (cbInputUnit != null) applyUnit();
    }

    // ── FXML init ─────────────────────────────────────────────────────────
    @FXML
    public void initialize() {
        // Populate the input-unit picker
        cbInputUnit.setItems(FXCollections.observableArrayList(Unit.values()));
        cbInputUnit.setValue(lastInputUnit);
        cbInputUnit.setOnAction(e -> applyUnit());

        // Table setup
        holesTable.setItems(rows);
        holesTable.setEditable(true);
        holesTable.getSelectionModel().setCellSelectionEnabled(true);

        holeStart.setCellValueFactory(cd -> new SimpleStringProperty(cd.getValue()[0]));
        holeSize .setCellValueFactory(cd -> new SimpleStringProperty(cd.getValue()[1]));
        holeStart.setCellFactory(EditCell.forTableColumn());
        holeSize .setCellFactory(EditCell.forTableColumn());
        holeStart.setOnEditCommit(e -> e.getRowValue()[0] = e.getNewValue());
        holeSize .setOnEditCommit(e -> e.getRowValue()[1] = e.getNewValue());

        // Restore previous session values (or defaults)
        if (hasInit) {
            // Convert stored bytes back to lastInputUnit for display
            double totalInUnit = (double) lastTotalBytes / lastInputUnit.getFactor();
            tfTotalSize.setText(formatInputValue(lastTotalBytes, lastInputUnit));
            for (String[] r : lastRows) rows.add(new String[]{r[0], r[1]});
        } else {
            tfTotalSize.setText("1024");
            rows.add(new String[]{"0", "1024"});
        }

        applyUnit();
    }

    /** Update labels and column headers when the unit picker changes. */
    private void applyUnit() {
        Unit u = cbInputUnit.getValue();
        if (u == null) return;
        lblTotalSize.setText("Total Memory Size (" + u.getLabel() + "):");
        holeStart.setText("Start (" + u.getLabel() + ")");
        holeSize .setText("Size  (" + u.getLabel() + ")");
    }

    // ── Table actions ─────────────────────────────────────────────────────
    @FXML private void onAddHoleRow()    { rows.add(new String[]{"0", "0"}); }
    @FXML private void onRemoveHoleRow() {
        int sel = holesTable.getSelectionModel().getSelectedIndex();
        if (sel >= 0) rows.remove(sel);
    }

    // ── OK ────────────────────────────────────────────────────────────────
    @FXML private void onOk() {
        Unit u = cbInputUnit.getValue();

        // Temporarily set inputUnit so parseAndValidate uses it
        units.setInputUnit(u);

        // --- Total size ---
        long totalB;
        try {
            totalB = units.parseAndValidate(tfTotalSize.getText());
        } catch (IllegalArgumentException ex) {
            alert("Total memory size: " + ex.getMessage()); return;
        }

        // --- Holes ---
        holes.clear();
        for (int i = 0; i < rows.size(); i++) {
            String[] row = rows.get(i);

            // Start address: must be a non-negative integer in the chosen unit
            long startB;
            try {
                double sd = Double.parseDouble(row[0].trim());
                if (sd < 0) throw new IllegalArgumentException("Start address cannot be negative.");
                startB = (long)(sd * u.getFactor());
                if (startB < 0)
                    throw new IllegalArgumentException("Start address out of range.");
            } catch (NumberFormatException ex) {
                alert("Hole " + (i+1) + " start: \"" + row[0] + "\" is not a valid number."); return;
            } catch (IllegalArgumentException ex) {
                alert("Hole " + (i+1) + " start: " + ex.getMessage()); return;
            }

            // Size: must be power-of-two bytes
            long sizeB;
            try {
                sizeB = units.parseAndValidate(row[1]);
            } catch (IllegalArgumentException ex) {
                alert("Hole " + (i+1) + " size: " + ex.getMessage()); return;
            }

            if (startB + sizeB > totalB) {
                alert("Hole " + (i+1) + " [" + row[0] + " → +" + row[1] + " "
                        + u.getLabel() + "] exceeds total memory."); return;
            }

            holes.add(new long[]{startB, sizeB});
        }

        if (holes.isEmpty()) holes.add(new long[]{0L, totalB});

        // Persist for next open
        totalSizeBytes = totalB;
        lastTotalBytes = totalB;
        lastInputUnit  = u;
        lastRows.clear();
        for (String[] r : rows) lastRows.add(new String[]{r[0], r[1]});
        hasInit = true;

        confirmed = true;
        close();
    }

    @FXML private void onCancel() { close(); }

    // ── Helpers ───────────────────────────────────────────────────────────
    private void close() { ((Stage) tfTotalSize.getScene().getWindow()).close(); }

    private void alert(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        a.setHeaderText("Invalid input");
        a.showAndWait();
    }

    /** Format bytes in a given unit without trailing zeros. */
    private static String formatInputValue(long bytes, Unit u) {
        if (u == Unit.B) return String.valueOf(bytes);
        if (bytes % u.getFactor() == 0) return String.valueOf(bytes / u.getFactor());
        return String.valueOf((double) bytes / u.getFactor());
    }

    // ── Result getters ────────────────────────────────────────────────────
    public boolean    isConfirmed()      { return confirmed; }
    /** Total memory in RAW BYTES. */
    public long       getTotalSizeBytes(){ return totalSizeBytes; }
    /** Each long[]: [startBytes, sizeBytes]. */
    public List<long[]> getHoleBytes()   { return holes; }
}
