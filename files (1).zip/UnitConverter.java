package model.service;

/**
 * Converts raw byte values to/from the user-selected units.
 *
 * Two independent unit slots:
 *   inputUnit   — the unit the user TYPES sizes in (chosen in the
 *                 "Initialise Memory" dialog, fixed for the session).
 *   displayUnit — the unit used when SHOWING values in tables and the
 *                 diagram (freely changeable from the main window ComboBox).
 *
 * All internal storage is always raw bytes (int/long) — no rounding ever
 * happens inside the model.  Conversion only happens at the UI boundary:
 *   • input  : user string → bytes  (parseAndValidate / toInputBytes)
 *   • output : bytes       → string (format / formatValue)
 *
 * Power-of-two rule:
 *   Every byte count that originates from user input must be a power of two.
 *     1000 KB = 1 024 000 B  → isPowerOfTwo → false  ✗
 *     1024 KB = 1 048 576 B  → isPowerOfTwo → true   ✓
 *   parseAndValidate() enforces this and gives a human-friendly error.
 */
public class UnitConverter {

    public enum Unit {
        B  ("B",   1L),
        KB ("KB",  1_024L),
        MB ("MB",  1_024L * 1_024),
        GB ("GB",  1_024L * 1_024 * 1_024);

        private final String label;
        private final long   factor;

        Unit(String label, long factor) {
            this.label  = label;
            this.factor = factor;
        }

        public String getLabel()  { return label; }
        public long   getFactor() { return factor; }

        @Override public String toString() { return label; }
    }

    // ── Singleton ──────────────────────────────────────────────────────────
    private static final UnitConverter INSTANCE = new UnitConverter();
    public static UnitConverter getInstance() { return INSTANCE; }

    // ── State ──────────────────────────────────────────────────────────────
    private Unit inputUnit   = Unit.B;   // typing unit  (set by init dialog)
    private Unit displayUnit = Unit.B;   // viewing unit (set by main ComboBox)

    // ── Input-unit API ─────────────────────────────────────────────────────

    public void setInputUnit(Unit u)  { this.inputUnit = u; }
    public Unit getInputUnit()        { return inputUnit; }
    public String inputLabel()        { return inputUnit.getLabel(); }

    /**
     * Convert a user value (in the current inputUnit) to raw bytes.
     * Exact: multiplies by the factor with no rounding (caller must have
     * already validated via isPowerOfTwo).
     */
    public long toInputBytes(double userValue) {
        return (long)(userValue * inputUnit.getFactor());
    }

    /** Raw bytes → inputUnit double (for pre-filling dialog fields). */
    public double fromInputBytes(long bytes) {
        return (double) bytes / inputUnit.getFactor();
    }

    // ── Display-unit API ───────────────────────────────────────────────────

    public void setDisplayUnit(Unit u) { this.displayUnit = u; }
    public Unit getDisplayUnit()       { return displayUnit; }

    /**
     * Format a raw byte count for display using displayUnit.
     * Exact integer when divisible; 3 d.p. otherwise.
     */
    public String format(long bytes) {
        if (displayUnit == Unit.B) return bytes + " B";
        long factor = displayUnit.getFactor();
        if (bytes % factor == 0)
            return (bytes / factor) + " " + displayUnit.getLabel();
        return trimZeros(String.format("%.3f", (double) bytes / factor))
               + " " + displayUnit.getLabel();
    }

    /** Like format() but omits the unit suffix (for table cells). */
    public String formatValue(long bytes) {
        if (displayUnit == Unit.B) return String.valueOf(bytes);
        long factor = displayUnit.getFactor();
        if (bytes % factor == 0) return String.valueOf(bytes / factor);
        return trimZeros(String.format("%.4f", (double) bytes / factor));
    }

    /** Display unit label, e.g. "MB". */
    public String label() { return displayUnit.getLabel(); }

    // Shims so unchanged callers still compile
    /** @deprecated use setDisplayUnit */
    @Deprecated public void setUnit(Unit u) { setDisplayUnit(u); }
    /** @deprecated use getDisplayUnit */
    @Deprecated public Unit getUnit()       { return getDisplayUnit(); }

    // ── Power-of-two validation ────────────────────────────────────────────

    /**
     * True iff bytes is a positive power of two (2^n, n >= 0).
     *   isPowerOfTwo(1024)    → true
     *   isPowerOfTwo(1000)    → false
     *   isPowerOfTwo(0)       → false
     */
    public static boolean isPowerOfTwo(long bytes) {
        return bytes > 0 && (bytes & (bytes - 1)) == 0;
    }

    /**
     * Parse the user string as a number in inputUnit → bytes,
     * then verify the byte count is a positive power of two.
     * Returns the byte count on success.
     * Throws IllegalArgumentException with a friendly message on failure.
     */
    public long parseAndValidate(String raw) {
        double d;
        try {
            d = Double.parseDouble(raw.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("\"" + raw + "\" is not a valid number.");
        }
        if (d <= 0)
            throw new IllegalArgumentException("Size must be positive (got " + d + " " + inputUnit.getLabel() + ").");

        long bytes = (long)(d * inputUnit.getFactor());
        if (bytes <= 0)
            throw new IllegalArgumentException(
                    "Computed byte count is zero or negative.\n"
                    + "Check that the value is large enough for the selected unit.");
        if (!isPowerOfTwo(bytes))
            throw new IllegalArgumentException(
                    d + " " + inputUnit.getLabel() + " = " + bytes
                    + " B, which is NOT a power of 2.\n"
                    + "Nearest valid values: "
                    + suggestNearest(bytes, inputUnit));
        return bytes;
    }

    // ── Private helpers ────────────────────────────────────────────────────

    private static String trimZeros(String s) {
        return s.replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private static String suggestNearest(long bytes, Unit unit) {
        long lo = Long.highestOneBit(bytes);
        long hi = (lo == bytes) ? bytes : lo << 1;
        long a  = nearestInUnit(lo, unit);
        long b  = nearestInUnit(hi, unit);
        return formatInUnit(lo, unit) + " " + unit.getLabel()
             + " (" + lo + " B) or "
             + formatInUnit(hi, unit) + " " + unit.getLabel()
             + " (" + hi + " B)";
    }

    private static long nearestInUnit(long bytes, Unit unit) {
        return bytes / unit.getFactor();
    }

    private static String formatInUnit(long bytes, Unit unit) {
        if (unit == Unit.B) return String.valueOf(bytes);
        if (bytes % unit.getFactor() == 0)
            return String.valueOf(bytes / unit.getFactor());
        return trimZeros(String.format("%.4f", (double) bytes / unit.getFactor()));
    }
}
