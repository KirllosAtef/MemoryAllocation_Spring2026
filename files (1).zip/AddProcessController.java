package controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.*;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.service.UnitConverter;
import view.util.EditCell;

import java.util.*;

/**
 * Controller for addProcess.fxml.
 *
 * Segment sizes are entered in UnitConverter.inputUnit (set by the init
 * dialog) and validated as positive powers of two in bytes.
 * Raw byte counts are returned to MainController.
 */
public class AddProcessController {

    @FXML private TextField                     tfName;
    @FXML private TableView<String[]>           segTable;
    @FXML private TableColumn<String[], String> colSegName, colSegSize;

    private final ObservableList<String[]> rows = FXCollections.observableArrayList();
    private boolean      confirmed = false;
    private String       procName;
    /** Each String[2]: [segmentName, rawBytesAsString]. */
    private final List<String[]> segments = new ArrayList<>();

    // ── Injected ──────────────────────────────────────────────────────────
    private UnitConverter units;

    public void setUnitConverter(UnitConverter units) {
        this.units = units;
        updateSizeHeader();
    }

    /** Pre-populate for Edit mode. sizes[] values are raw bytes as strings. */
    public void initData(String name, List<String[]> existingSegments) {
        if (tfName != null) tfName.setText(name);
        rows.clear();
        // Convert stored raw bytes to inputUnit for display
        for (String[] seg : existingSegments) {
            String displaySize = seg[1]; // already raw bytes; show in inputUnit
            if (units != null) {
                try {
                    long bytes = Long.parseLong(seg[1]);
                    double inUnit = units.fromInputBytes(bytes);
                    displaySize = (bytes % units.getInputUnit().getFactor() == 0)
                            ? String.valueOf((long) inUnit)
                            : String.valueOf(inUnit);
                } catch (NumberFormatException ignored) {}
            }
            rows.add(new String[]{seg[0], displaySize});
        }
    }

    @FXML
    public void initialize() {
        updateSizeHeader();

        segTable.setItems(rows);
        segTable.setEditable(true);
        segTable.getSelectionModel().setCellSelectionEnabled(true);

        colSegName.setCellValueFactory(cd -> new SimpleStringProperty(cd.getValue()[0]));
        colSegSize.setCellValueFactory(cd -> new SimpleStringProperty(cd.getValue()[1]));
        colSegName.setCellFactory(EditCell.forTableColumn());
        colSegSize.setCellFactory(EditCell.forTableColumn());
        colSegName.setOnEditCommit(e -> e.getRowValue()[0] = e.getNewValue());
        colSegSize.setOnEditCommit(e -> e.getRowValue()[1] = e.getNewValue());

        if (rows.isEmpty()) {
            rows.addAll(
                new String[]{"Code",  "50"},
                new String[]{"Data",  "200"},
                new String[]{"Stack", "100"}
            );
        }
    }

    private void updateSizeHeader() {
        String lbl = units != null ? units.inputLabel() : "B";
        if (colSegSize != null) colSegSize.setText("Size (" + lbl + ")");
    }

    @FXML private void onAddRow()    { rows.add(new String[]{"Segment", "0"}); }
    @FXML private void onRemoveRow() {
        int sel = segTable.getSelectionModel().getSelectedIndex();
        if (sel >= 0) rows.remove(sel);
    }

    @FXML private void onAdd() {
        procName = tfName.getText().trim();
        if (procName.isEmpty()) { alert("Process name cannot be empty."); return; }
        if (rows.isEmpty())     { alert("Add at least one segment.");     return; }

        segments.clear();
        for (String[] row : rows) {
            String sn = row[0].trim(), ss = row[1].trim();
            if (sn.isEmpty() || ss.isEmpty()) { alert("Segment name/size cannot be empty."); return; }
            long bytes;
            try {
                bytes = units.parseAndValidate(ss);
            } catch (IllegalArgumentException ex) {
                alert("Segment \"" + sn + "\" size: " + ex.getMessage()); return;
            }
            // Store raw bytes as string so MainController parses via Long.parseLong
            segments.add(new String[]{sn, String.valueOf(bytes)});
        }
        confirmed = true;
        close();
    }

    @FXML private void onCancel() { close(); }

    private void close() { ((Stage) tfName.getScene().getWindow()).close(); }
    private void alert(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        a.setHeaderText("Invalid input");
        a.showAndWait();
    }

    public boolean       isConfirmed()  { return confirmed; }
    public String        getProcName()  { return procName; }
    /** Each String[2]: [name, rawBytesAsString]. */
    public List<String[]> getSegments() { return segments; }
}
